﻿=== قالب‌گر بلاگفا ===
Contributors: shazdeh
Tags: theme, template
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 0.3
License: GPLv2 or later

نمایش قالب‌های بلاگفا در وردپرس

== Description ==

این افزونه به شما این امکان را می‌دهد که بتوانید از قالب‌های نوشته شده برای بلاگفا در وردپرس خود استفاده کنید.

= مهم‌ترین ویژگی‌ها =
* پشتیبانی از تمام تگ‌های بلاگفا
* قابلیت استفاده در وردپرس شبکه (چند کاربره)
* پشتیبانی از افزونه جلالی برای نمایش تاریخ‌های شمسی

= پشتیبانی از ابزارک‌ها =
دو ناحیه ابزارک با نام‌های «بالای محتوا» و «پایین محتوا» وجود دارد که در بالا یا پایین نوشته‌هایتان به نمایش درمی‌آیند. اما متاسفانه امکان پشتیبانی از نواحی دیگری مثل ستون کناری وجود ندارد و این به دلیل عدم پشتیبانی سیستم بلاگفا از این ویژگی است. برای کسب اطلاعات بیشتر به صفحه خانه افزونه مراجعه نمایید.

= پشتیبانی =
سوالی دارید یا متوجه مشکلی در افزونه شده‌اید؟ می‌توانید با من <a href="http://tween.ir/%d8%aa%d9%85%d8%a7%d8%b3-%d8%a8%d8%a7-%d9%85%d9%86/">تماس بگیرید</a>.


== Installation ==

1. Upload the whole plugin directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Goto Appearance -> Blogfa Options.
4. Enjoy!

== Changelog ==

= 0.3 =
* Performance boosts with "template compilation" and chaching
* Major security fix
* MU compatible
* Added support for Post Thumbnails and Custom Backgrounds
* Added "Above Content" and "Below Content" widget areas
* Code Refactor!

= 0.2 =
* Added support for more Blogfa's template tags