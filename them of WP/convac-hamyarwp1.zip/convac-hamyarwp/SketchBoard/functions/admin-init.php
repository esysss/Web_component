<?php
/********************************************
 FRAME WORK CODE STARTS HERE
*********************************************/
/********************************************
 THEME VARIABLES
*********************************************/
global $convac_lite_themename;
global $convac_lite_shortname;
require_once('sketch-functions.php');                      // PAGINATION, EXCERPT CONTROL ETC.
require_once('sketch-enqueue.php');                        // ENQUEUE CSS SCRIPTS
require_once('sketch-breadcrumb.php');                     // BREADCRUMB INCLUDES