<?php

global $convac_lite_themename;
global $convac_lite_shortname;

/**
 * Initialize the options before anything else. 
 */
add_action( 'admin_init', '_custom_theme_options', 1 );

/**
 * Theme Mode demo code of all the available option types.
 *
 * @return    void
 *
 * @access    private
 * @since     2.0
 */
function _custom_theme_options() {

global $convac_lite_themename;
global $convac_lite_shortname;
  
   /**
    * Get a copy of the saved settings array. 
    */
	$saved_settings = get_option( 'option_tree_settings', array() );

	
	// If using image radio buttons, define a directory path
	$imagepath  =  get_template_directory_uri() . '/images/';
	$sktsiteurl = home_url();
	$sktsitenm  = get_bloginfo('name');
	
  /**
   * Create a custom settings array that we pass to 
   * the OptionTree Settings API Class.
   */
  $custom_settings = array(
    'contextual_help' => array(
		'content'       => array( 
			array(
				'id'        => 'general_help',
				'title'     => 'General',
				'content'   => '<p>Help content goes here!</p>'
			)
		),
		'sidebar'     => '<p>Sidebar content goes here!</p>'
		),
		'sections'        => array(
			array(
				'title'   => 'تنظیمات عمومی',
				'id'      => 'general_default'
			),
			array(
				'title'   => 'تنظیمات هدر',
				'id'      => 'header_settings'
			),
			array(
				'title'   => 'تنظیمات نویسنده',
				'id'      => 'author_settings'
			), 
			array(      
				'title'   => 'تنظیمات شبکه های اجتماعی',
				'id'      => 'social_links'

			),
			array(      
				'title'   => 'تنظیمات صفحه های داخلی',
				'id'      => 'innerpage_settings'

			),
			array(
				'title'   => 'تنظیمات وبلاگ',
				'id'      => 'blog_settings'
			), 			
			array(      
				'title'   => 'تنظیمات فوتر',
				'id'      => 'footer_section'
			),
		),
    'settings'        => array(
	

		//==================================================================
		// GENERAL SETTINGS SECTION STARTS =================================
		//==================================================================
		
		array(
			'id'          => 'convac_welcome_speach',
			'label'       => 'Welcome to Convac',
			'desc'        => '<h1>به Convac خوش امدید</h1>
			<p>از این که این پوسته را انتخاب کردید متشکریم . این پوسته توسط همیار وردپرس ترجمه شده است</p>',
			'std'         => '',
			'type'        => 'textblock',
			'section'     => 'general_default',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'class'       => ''
		),
		array(
			'label'       => __( 'طرح رنگ', 'convac-lite'),
			'id'          => $convac_lite_shortname.'_colorpicker',
			'type'        => 'colorpicker',
			'desc'        => 'یک رنگ انتخاب کنید',
			'std'         => '#f65e13',
			'section'     => 'general_default'
		),
		array(
			'label'       => __( 'فیو ایکن', 'convac-lite'),
			'id'          => $convac_lite_shortname.'_favicon',
			'type'        => 'upload',
			'desc'        => 'یک فیو ایکن برای وب سایت خود اپلود کنید',
			'std'         => '',
			'section'     => 'general_default'
		),
		array(
			'id'          => $convac_lite_shortname.'_show_pagination',
			'label'       => __('صفحه بندی سفارشی', 'convac-lite'),
			'desc'        => __('فعال یا غیر فعال کنید حالت صفحه بندی سفارشی', 'convac-lite'),
			'type'        => 'فعال-غیرفعال',
			'std'         => 'on',
			'section'     => 'general_default'
		),


		//------ END GENERAL SETTINGS SECTION ------------------------------
		
		
		//==================================================================
		// HEADER SETTINGS SECTION STARTS ==================================
		//==================================================================	

		
		array(
			'label'       => __( 'تصویر استاتیک سربرگ', 'convac-lite'),
			'id'          => $convac_lite_shortname.'_header_static_img',
			'type'        => 'upload',
			'desc'        => 'یک سربرگ اپلود کنید',
			'std'         => '',
			'section'     => 'header_settings'
		),
		array(
			'label'       => __( 'تغییر لوگو', 'convac-lite'),
			'id'          => $convac_lite_shortname.'_logo_img',
			'type'        => 'upload',
			'desc'        => 'یک لوگو برای وب سایت خود اپلود کنید',
			'std'         => '',
			'section'     => 'header_settings'
		),
		array(
			'id'          => $convac_lite_shortname.'_logo_alt',
			'label'       => __( 'لوگو نوشته', 'convac-lite'),
			'desc'        => 'یک لوگو نوشته وارد کنید',
			'std'         => '',
			'type'        => 'text',
			'section'     => 'header_settings'
		),	
		array(
			'id'          => $convac_lite_shortname.'_moblie_menu',
			'label'       => __( 'Mobile Menu Activate Width', 'convac-lite'),
			'desc'        => __( 'Layout width after which mobile menu will get activated', 'convac-lite' ),
			'std'         => '1025',
			'type'        => 'numeric-slider',
			'section'     => 'header_settings',
			'rows'        => '',
			'post_type'   => '',
			'taxonomy'    => '',
			'min_max_step'=> '100,1180,1'

		),
		array(
			'label'       => __('گزینه سرچ در هدر', 'convac-lite'),
			'desc'        => __('گزینه سرچ را در هدر فعال یا غیرفعال کنید', 'convac-lite'),
			'id'          => $convac_lite_shortname.'_headserach',
			'std'         => 'on',
			'type'        => 'فعال-غیرفعال',
			'section'     => 'header_settings'
        ),
		
		//------ END HEADER SETTINGS SECTION -------------------------------
		
		
		//==================================================================
		// AUTHOR SETTINGS SECTION STARTS ============================
		//==================================================================
		array(
			'label'       => __( 'تصویر برای نویسنده ', 'convac-lite'),
			'id'          => $convac_lite_shortname.'_author_img',
			'type'        => 'upload',
			'desc'        => 'یک تصویر برای نویسنده اپلود کنید',
			'std'         => '',
			'section'     => 'author_settings'
			),
		array(
			'id'          => $convac_lite_shortname.'_author_name',
			'label'       => __( 'نام نویسنده', 'convac-lite'),
			'desc'        => 'نام نویسنده را وارد کنید',
			'std'         => '',
			'type'        => 'text',
			'section'     => 'author_settings'
			),
		array(
			'label'       => 'توضیحاتی درباره نویسنده',
			'id'          => $convac_lite_shortname.'_author_desp',
			'type'        => 'textarea-simple',
			'desc'        => 'توضیحاتی در باره نویسنده بنویسید',
			'std'         => '',
			'section'     => 'author_settings'
		),	
			
		//------ END AUTHOR SETTINGS SECTION -------------------------------
			
			
		//==================================================================
		// SOCIAL LINKS SETTINGS SECTION STARTS ============================
		//==================================================================
		
		
		array(
			'label'       => 'متن عنوان شبکه های اجتماعی',
			'id'          => $convac_lite_shortname.'_sconnect_txt',
			'type'        => 'text',
			'desc'        => 'یک متن بنویسید',
			'std'         => '',
			'section'     => 'social_links'
		),
	  	array(
			'label'       => 'لینک فیسبوک',
			'id'          => $convac_lite_shortname.'_fbook_link',
			'type'        => 'text',
			'desc'        => 'لینک فیسبوک خود را وارد کنید',
			'std'         => '',
			'section'     => 'social_links'
		),
		array(
			'label'       => 'لینک توییتر',
			'id'          => $convac_lite_shortname.'_twitter_link',
			'type'        => 'text',
			'desc'        => 'لینک توییتر خود را وارد کنید',
			'std'         => '',
			'section'     => 'social_links'
		),
		array(
			'label'       => 'ایدی گوگل پلاس',
			'id'          => $convac_lite_shortname.'_gplus_link',
			'type'        => 'text',
			'desc'        => 'ایدی گوگل پلاس خود را وارد کنید',
			'std'         => '',
			'section'     => 'social_links'
		),
		array(
			'label'       => 'Linkedin Link',
			'id'          => $convac_lite_shortname.'_linkedin_link',
			'type'        => 'text',
			'desc'        => 'Enter Linkedin link.',
			'std'         => '',
			'section'     => 'social_links'
		),	
		array(
			'label'       => 'Pinterest Link',
			'id'          => $convac_lite_shortname.'_pinterest_link',
			'type'        => 'text',
			'desc'        => 'Enter Pinterest link.',
			'std'         => '',
			'section'     => 'social_links'
		),	
		array(
			'label'       => 'لینک فیلکر',
			'id'          => $convac_lite_shortname.'_flickr_link',
			'type'        => 'text',
			'desc'        => 'لینک فیلکر خود را وارد کنید',
			'std'         => '',
			'section'     => 'social_links'
		),
		array(
			'label'       => 'Foursquare Link',
			'id'          => $convac_lite_shortname.'_foursquare_link',
			'type'        => 'text',
			'desc'        => 'Enter Foursquare link.',
			'std'         => '',
			'section'     => 'social_links'
		),		
		array(
			'label'       => 'لینک یوتیوب',
			'id'          => $convac_lite_shortname.'_youtube_link',
			'type'        => 'text',
			'desc'        => 'لینک یوتیوب خود را وارد کنید',
			'std'         => '',
			'section'     => 'social_links'
		),
	   
		//------ END SOCIAL LINKS SETTINGS SECTION -------------------------
		
				
		
		//==================================================================
		// BLOG SETTINGS SECTION STARTS ====================================
		//==================================================================	

		array(
			'id'          => $convac_lite_shortname.'_blogpage_heading',
			'label'       => __( 'Enter Blog Page Title', 'convac-lite'),
			'desc'        => 'Enter Blog Page Title text.',
			'std'         => 'Blog',
			'type'        => 'text',
			'section'     => 'blog_settings'
		),
			
		//------ END BLOG SETTINGS SECTION ---------------------------------
	

	
		//==================================================================
		// INNER PAGE SETTINGS SECTION STARTS ====================================
		//==================================================================	

		array(
			'label'       => __( ' سربرگ ', 'convac-lite'),
			'id'          => $convac_lite_shortname.'_innerpage_img',
			'type'        => 'upload',
			'desc'        => 'یک سربرگ اپلود کنید',
			'std'         => '',
			'section'     => 'innerpage_settings'
			),
			
		//------ END INNER PAGE SETTINGS SECTION ---------------------------------
	
		//==================================================================
		// FOOTER SETTINGS SECTION STARTS ==================================
		//==================================================================
		
		array(
			'label'       => 'متن کپی رایت',
			'id'          => $convac_lite_shortname.'_copyright',
			'type'        => 'textarea',
			'desc'        => 'یک متن کپی رایت وارد کنید',
			'std'         => 'Copyright text',
			'section'     => 'footer_section'
		),		
		
		
		//------ END FOOTER SETTINGS SECTION -------------------------------
		
		
			
    )
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( 'option_tree_settings_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( 'option_tree_settings', $custom_settings ); 
  }
  
}

?>