<div class="Skt-header-image">
	<!-- header image -->
		<div class="convac-image-post"><img alt="convac-default-slider-image" class="ad-slider-image" src="<?php if(convac_lite_get_option($convac_lite_shortname.'_frontslider_stype')) { echo convac_lite_get_option($convac_lite_shortname.'_frontslider_stype'); } else { echo get_template_directory_uri().'/images/header-static-img.jpg';}?>" ></div>
	<!-- end  header image  -->
</div>