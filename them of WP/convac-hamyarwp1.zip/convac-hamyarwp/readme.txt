== Copyright and License ==

Convac Lite WordPress Theme, Copyright 2014 SketchThemes.
Convac Lite WordPress theme is distributed under the terms of the GNU GPL.


/*========= Credits =========*/

--------------------- Script Credits "Convac Lite WordPress Theme" ---------------------

* The script cbpAnimatedHeader.js v1.0.0 is licensed under the MIT license.(https://github.com/codrops/AnimatedHeader)
* The script jquery.easing.1.3.js v1.3.0 is licensed under the BSD License.(https://github.com/gdsmith/jquery.easing/blob/master/jquery.easing.1.3.js)
* The script superfish.js v1.7.4 is licensed under the MIT and GPL.(https://github.com/joeldbirch/superfish)
* The script waypoints.min.js is licensed under the MIT.(https://github.com/imakewebthings/jquery-waypoints)
* The script jquery.prettyPhoto.js is licensed under the GPLV2 license.(http://www.no-margin-for-errors.com/projects/prettyPhoto/)

--------------------- CSS Credits "Convac Lite WordPress Theme" ---------------------
* The CSS bootstrap-responsive.css is licensed under the Apache License v2.0.
* The CSS font-awesome.css is licensed under the MIT License.
* The CSS prettyPhoto.css is licensed under the "GPLv2 license".
* The CSS superfish.css is licensed under  MIT and GPL.
* The CSS flexslider.css is licensed under GPLv2 license.

--------------------- Option Tree Credits "Convac Lite WordPress Theme" ---------------------
* Option Tree Framework is licensed under GPLv3�(https://github.com/valendesigns/option-tree-theme)


--------------------- Font Credits "Convac Lite WordPress Theme" ---------------------

* Icon Set: FontAwesome is licensed under MIT License� (http://fortawesome.github.io/Font-Awesome/)
* Google Webfonts: Open Sans Script is licensed under Apache License, version 2.0 (https://www.google.com/fonts/specimen/Open+Sans)


--------------------- Image credits "Convac Lite WordPress Theme" ---------------------

* Timeliner_Modeling_Demo.png
	http://pixabay.com/en/girl-woman-exotic-beauty-model-97433/
	http://pixabay.com/en/girl-model-pretty-portrait-lady-97088/

* irex-mac-420px.png
	http://pixabay.com/en/couple-bride-love-wedding-bench-260899/

* fullscreen-mac-420px.png
	http://pixabay.com/en/girl-woman-sexy-lingerie-posing-254708/

* bizstudio-default-demo.png
	http://pixabay.com/en/beach-beautiful-blue-female-girl-15689/
	http://pixabay.com/en/sea-blue-sky-sand-beach-holiday-142459/

* biznez-career-counseling-demo.png
	http://unsplash.s3.amazonaws.com/batch%203/doctype-hi-res.jpg

* Advertica_screen_420px.png
	http://666a658c624a3c03a6b2-25cda059d975d2f318c03e90bcf17c40.r92.cf1.rackcdn.com/unsplash_522b53fb137bb_1.jpg

* sketchmini-mac-420px.png
	http://pixabay.com/en/blue-summer-woman-mom-people-joy-69762/
	http://pixabay.com/en/couple-people-girlfriend-boyfriend-17102/
	http://pixabay.com/en/red-people-sunlight-promenade-211709/

* Invert-mac-300px.png
	The Slider Image was made in Photoshop from scratch. Hence No Attribution is required.

* Analytical_Interior_Demo.png
	http://publicdomainarchive.com/girl-nature-outdoors-autumn-lens-flare-sun-rays/


* header-static-img.jpg :- 
http://publicdomainarchive.com/wheat-stalk-blue-teal-dark-background/public-domain-images-archive-high-quality-resolution-free-download-splitshire-0001/

* girl-image :-
http://pixabay.com/en/girl-outdoors-smiling-happy-358770/


* All other images were created by SketchThemes as per requirement.




== Changelog ==

= 1.0.5 =
* Fixed load unnessary scripts on other admin pages.

= 1.0.4 =
* Added escaping.
* Added girl-image license url.
* Added Flexslider license.
* Change functions prefix.
 
= 1.0.3 =
* Fixed Theme Check issue(register_post_type and screen_icon).
* Some style fixes.

= 1.0.2 =

* Fixed Logo image issue.
* Fixed blog page CSS issue. 

= 1.0.1 =
* Fixed Front page displays option settings issue.
* Breadcrumb header layout css isuue.

= 1.0.0 =
* Initial release
