<?php
/**
 * The sidebar containing the secondary widget area, displays on posts.
 * If no active widgets in this sidebar, it will be hidden completely.
 */	
?>
<div id="sidebar_2" class="ske_widget">
	<ul class="skeside">
		<?php dynamic_sidebar( 'Blog Sidebar' ); ?>
<div class="boxha">
<h2>ویدیوی جدید ما</h2>
<iframe src="http://www.aparat.com/video/video/embed/videohash/4wHGT/vt/frame" allowFullScreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" height="320" width="569" ></iframe>
	</ul>
</div>
<!-- #sidebar_2 .ske_widget -->
 



