<?php
class pluginbuddy_importbuddy_step_0 {
	function __construct( &$parent ) {
		$this->_parent = &$parent;
	}
}
?>